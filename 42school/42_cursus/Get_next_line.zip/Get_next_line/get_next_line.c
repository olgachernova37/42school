/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olcherno <olcherno@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/06 13:21:53 by olcherno          #+#    #+#             */
/*   Updated: 2025/01/07 16:37:57 by olcherno         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static char	*reading(int fd, char *left_c, char *buffer);
static char	*cutting_line(char *line);
static char	*ft_strchr(char *s, int c);

char	*get_next_line(int fd)
{
	static char	*preread;
	char		*buffer;
	char		*line;

	buffer = (char *)malloc(sizeof(char) * (BUFFER_SIZE + 1));
	// printf("malloc5\n");
	if (fd < 0 || BUFFER_SIZE <= 0 || read(fd, 0, 0) < 0)
	{
		free(preread);
		free(buffer);
		preread = NULL;
		buffer = NULL;
		return (NULL);
	}
	if (!buffer)
	{
		free(preread);
		preread = NULL;
		return (NULL);
	}
	line = reading(fd, preread, buffer);
	free(buffer);
	buffer = NULL;
	if (!line)
		return (NULL);
	preread = cutting_line(line);
	return (line);
}
static char	*reading(int fd, char *preread, char *buffer)
{
	ssize_t	be_read;
	char	*temp;

	be_read = 1;
	while (be_read > 0)
	{
		be_read = read(fd, buffer, BUFFER_SIZE);
		if (be_read == -1)
		{
			free(preread);
			return (NULL);
		}
		if (be_read == 0)
			break ;
		buffer[be_read] = '\0';
		if (!preread)
			preread = ft_strdup("");
		if (preread == NULL)
			return  (NULL);
		temp = preread;
		preread = ft_strjoin(temp, buffer);
		// if (preread == NULL)
		// {
		// 	free(temp);
		// 	// free(buffer);
		// 	buffer = NULL;
		// 	return  (NULL);
		// }
		free(temp); 
		temp = NULL;
		if (ft_strchr(buffer, '\n'))
			break ;
	}
	return (preread);
}

static char	*cutting_line(char *line)
{
	char	*preread;
	ssize_t	i;

	i = 0;
	while (line[i] != '\n' && line[i] != '\0')
		i++;
	if (line[i] == 0 || line[1] == 0)
		return (NULL);
	preread = ft_substr(line, i + 1, ft_strlen(line) - i);
	if (!preread)
	{
		return (NULL);
	}
	if (*preread == 0)
	{
		free(preread);
		preread = NULL;
	}
	line[i + 1] = 0;
	return (preread);
}

static char	*ft_strchr(char *s, int c)
{
	unsigned int i;
	char cc;

	cc = (char)c;
	i = 0;
	while (s[i])
	{
		if (s[i] == cc)
			return ((char *)&s[i]);
		i++;
	}
	if (s[i] == cc)
		return ((char *)&s[i]);
	return (NULL);
}
